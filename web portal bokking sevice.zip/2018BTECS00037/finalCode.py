import Tkinter as tk
import pymongo

root = tk.Tk()
root.title('Hotel management Operations on MongoDb')
global session
global mycol

# get connection here

client = pymongo.MongoClient()
mydb = client['la4']
mycol=mydb['hotel']


def add():
    add_window = tk.Toplevel(root)
    add_window.title('Add contact record')
    # add_window.geometry('1024x768')

    # Row 0
    top_label = tk.Label(add_window,
                         text="Add details",
                         font=("Arial", 18),
                         pady=10,
                         fg='black')
    top_label.grid(row=0, column=0, padx=20)

    # Row 1
    type_label = tk.Label(add_window,
                        text="choose option: a) wedding 50,000 b) Birthday 10000 c) Corp. Meeting 5,000",
                        font=("Arial", 12),
                        pady=10,
                        fg='black')
    type_label.grid(row=1, column=0, padx=20)
    type_label_value = tk.Entry(add_window, width=20, font=("Arial", 12))
    type_label_value.grid(row=1, column=1)

    # Row 2
    no_label = tk.Label(add_window,
                        text="Enter data dd/mm/yyyy ",
                        font=("Arial", 12),
                        pady=10,
                        fg='black')
    no_label.grid(row=2, column=0, padx=20)
    no_value = tk.Entry(add_window, width=20, font=("Arial", 12))
    no_value.grid(row=2, column=1)

    price = 50000
    if type_label_value.get()=="b":
        price=10000
    elif type_label_value.get()=="c":
        price=5000
    def insert_into_mongo():
        res = {
            'type': type_label_value.get(),
            'price': price,
            'date': no_value.get(),
            'status': 'pending'
        }
        try:
            mycol.insert(res)
            confirm = tk.Label(add_window,
                               text="New event added successfully",
                               font=("Arial", 12),
                               pady=10,
                               fg='black')
            confirm.grid(row=3, column=1)
        except pymongo.DriverException as e:
            print("Error accessing collection", e)

    # Row 7
    submit = tk.Button(add_window,
                       text="Add to contacts",
                       command=insert_into_mongo,
                       font=("Arial", 10),
                       relief='raised',
                       bd=3,
                       bg='white')
    submit.grid(row=4,
                column=1,
                pady=20,
                padx=20,
                ipadx=8,
                ipady=5,
                columnspan=4)



def read():
    show_window = tk.Toplevel(root)
    show_window.title('Read all event records')
    data = [("id", "date", "type","price","status")]
    try:
        rows = mycol.find()
        for row in rows:
            data.append((row['_id'], row['date'], row['type'],row['price'],row['status']))

        for i in range(len(data)):
            for j in range(len(data[0])):
                e = tk.Entry(show_window,
                             width=20,
                             fg='blue',
                             font=('Arial', 16, 'bold'))
                e.grid(row=i, column=j)
                e.insert(tk.END, data[i][j])
    except pymongo.DriverException as e:
        print("Error accessing collection")


def update():
    add_window = tk.Toplevel(root)
    add_window.title('Add contact record')
    # add_window.geometry('1024x768')

    # Row 0
    top_label = tk.Label(add_window,
                         text="Add details",
                         font=("Arial", 18),
                         pady=10,
                         fg='black')
    top_label.grid(row=0, column=0, padx=20)

    # Row 1
    type_label = tk.Label(add_window,
                          text="choose option: a) wedding 50,000 b) Birthday 10000 c) Corp. Meeting 5,000",
                          font=("Arial", 12),
                          pady=10,
                          fg='black')
    type_label.grid(row=1, column=0, padx=20)
    type_label_value = tk.Entry(add_window, width=20, font=("Arial", 12))
    type_label_value.grid(row=1, column=1)

    # Row 2
    no_label = tk.Label(add_window,
                        text="Enter data dd/mm/yyyy ",
                        font=("Arial", 12),
                        pady=10,
                        fg='black')
    no_label.grid(row=2, column=0, padx=20)
    no_value = tk.Entry(add_window, width=20, font=("Arial", 12))
    no_value.grid(row=2, column=1)

    id_label = tk.Label(add_window,
                        text="enter id ",
                        font=("Arial", 12),
                        pady=10,
                        fg='black')
    id_label.grid(row=3, column=0, padx=20)
    id_label_value = tk.Entry(add_window, width=20, font=("Arial", 12))
    id_label_value.grid(row=3, column=1)

    status = tk.Label(add_window,
                        text="update status ",
                        font=("Arial", 12),
                        pady=10,
                        fg='black')
    status.grid(row=4, column=0, padx=20)
    status_value = tk.Entry(add_window, width=20, font=("Arial", 12))
    status_value.grid(row=4, column=1)

    price = 50000
    if type_label_value.get() == "b":
        price = 10000
    elif type_label_value.get() == "c":
        price = 5000


    def update_data():
        try:
            myquery={'_id':id_label_value.get()}
            newContact={
                'type': type_label_value.get(),
                'price': price,
                'date': no_value.get(),
                'status': status_value.get()
            }
            mycol.update_one(myquery, {'$set':newContact})

            confirm = tk.Label(update_window,
                               text="Your record was updated",
                               font=("Arial", 12),
                               pady=10,
                               fg='black')
            confirm.grid(row=5, column=0, columnspan=2)
        except pymongo.DriverException as e:
            print(e)

    submit = tk.Button(add_window,
                       text="Update",
                       command=update_data,
                       font=("Arial", 10),
                       relief='raised',
                       bd=3,
                       bg='white')
    submit.grid(row=5,
                column=0,
                pady=20,
                padx=20,
                ipadx=8,
                ipady=5,
                columnspan=2)


# functions to call from menu
def opted_admin():
    # check bookings
    update_window = tk.Toplevel(root)
    update_window.title('Update a contact')
    top_label = tk.Label(update_window,
                         text="Hotel management",
                         font=("Arial", 25),
                         fg='orange')
    top_label.grid(row=0, column=0, columnspan=2, padx=20)

    cassandra_btn = tk.Button(update_window,
                              text="read",
                              command=read,
                              font=("Arial", 10),
                              relief='raised',
                              bd=3,
                              bg='white', fg='orange')
    cassandra_btn.grid(row=1, column=0, pady=20, padx=20, ipadx=8, ipady=5)

    mongo_btn = tk.Button(update_window,
                          text="update status",
                          command=update,
                          font=("Arial", 10),
                          relief='raised',
                          bd=3,
                          bg='white', fg='orange')
    mongo_btn.grid(row=2, column=0, pady=20, padx=20, ipadx=8, ipady=5)
    # update bookings

def opted_user():
    update_window = tk.Toplevel(root)
    update_window.title('Update a contact')
    top_label = tk.Label(update_window,
                         text="Hotel management",
                         font=("Arial", 25),
                         fg='orange')
    top_label.grid(row=0, column=0, columnspan=2, padx=20)

    cassandra_btn = tk.Button(update_window,
                              text="create",
                              command=add,
                              font=("Arial", 10),
                              relief='raised',
                              bd=3,
                              bg='white', fg='orange')
    cassandra_btn.grid(row=1, column=0, pady=20, padx=20, ipadx=8, ipady=5)

    mongo_btn = tk.Button(update_window,
                          text="check status",
                          command=read,
                          font=("Arial", 10),
                          relief='raised',
                          bd=3,
                          bg='white', fg='orange')
    mongo_btn.grid(row=2, column=0, pady=20, padx=20, ipadx=8, ipady=5)

# main logic

top_label = tk.Label(root,
                     text="Hotel management",
                     font=("Arial", 25),
                     fg='orange')
top_label.grid(row=0, column=0, columnspan=2, padx=20)


cassandra_btn = tk.Button(root,
                           text="Admin Mode",
                           command=opted_admin,
                           font=("Arial", 10),
                           relief='raised',
                           bd=3,
                           bg='white',fg='orange')
cassandra_btn.grid(row=1, column=0, pady=20, padx=20, ipadx=8, ipady=5)

mongo_btn = tk.Button(root,
                           text="User Mode",
                           command=opted_user,
                           font=("Arial", 10),
                           relief='raised',
                           bd=3,
                           bg='white',fg='orange')
mongo_btn.grid(row=2, column=0, pady=20, padx=20, ipadx=8, ipady=5)

root.mainloop()
