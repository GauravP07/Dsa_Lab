Create or replace type AddrType1 as object( 
	Pincode number(5),										        
	Street char(20),											        
	City varchar2(50),										         
	state varchar2(40), 										       
  	no number(4)
);

Create or replace type BranchType as object(
	address AddrType1,											
	phone1 integer,
	phone2 integer
);

Create or replace type BranchTableType as table of BranchType;

Create or replace type AuthorType as object(
	name varchar2(50),
	addr AddrType1
);

Create table Author of AuthorType;


Create or replace type AuthorListType as array(10) of ref AuthorType;

Create or replace type PublisherType as object(
	name varchar2(50),
	addr AddrType1, 
	branches BranchTableType
);

Create table Publisher of PublisherType NESTED TABLE branches STORE as branchstable;

Create table book(
	title varchar2(50),
	year date,
	published_by ref PublisherType,
	authors AuthorListType
);

insert into Author values('Shivani',AddrType1(4150,'streeta','satara','mha',1008));
insert into Author values('shruti',AddrType1(4151,'streetb','sangli','mha',1004));
insert into Author values('Revati',AddrType1(4152,'streeta','vaduj','mha',1003));
insert into Author values('Nida',AddrType1(4153,'streetb','solapur','mha',1008));
insert into Author values('Ganesh',AddrType1(4154,'streetc','jalgaon','mha',1008));
insert into Author values('Sudhanshu',AddrType1(4154,'streetb','nagpur','mha',1006));
insert into Author values('Minal',AddrType1(4151,'streeta','pune','kolhapur',1003));
insert into Author values('Anuja',AddrType1(4150,'streete','pune','satara',1010));
insert into Author values('piyush',AddrType1(4151,'streeta','pune','kolhapur',1003));
insert into Author values('rushikesh',AddrType1(4150,'streete','pune','satara',1010));


insert into Publisher values('pranita',AddrType1(4002,'streeta','mumbai','mha',03),
    BranchTableType(BranchType(AddrType1(4150,'streeta','satara','mha',03),12345,67543)));
insert into Publisher values('aditi', AddrType1(7007,'streeta','mumbai','mha',1007),
    BranchTableType(BranchType(AddrType1(4153,'streeta','solapur','mha',1007),979786,453567)));
insert into Publisher values('prasad',AddrType1(7008,'streeta','mumbai','mha',1007),
    BranchTableType(BranchType(AddrType1(4153,'streeta','solapur','mha',1007),979786,453567)));
insert into Publisher values('aditi', AddrType1(7002,'streeta','pune','mha',1007),
    BranchTableType(BranchType(AddrType1(4151,'streeta','pune','mha',1007),979786,453567)));
insert into Publisher values('tanaya',AddrType1(6002,'streeta','nasik','mha',1007),
    BranchTableType(BranchType( AddrType1(4151,'streeta','pune','kolhapur',1007),979786,453567)));
insert into Publisher values('arpita',AddrType1(6002,'streeta','nasik','mha',1007),
    BranchTableType(BranchType( AddrType1(4151,'streeta','nasik','kolhapur',1007),979786,453567)));
insert into Publisher values('prasad',AddrType1(7008,'streeta','mumbai','mha',1007),
    BranchTableType(BranchType(AddrType1(4153,'streeta','solapur','mha',1007),979786,453567)));
insert into Publisher values('aditi', AddrType1(7002,'streeta','pune','mha',1007),
    BranchTableType(BranchType(AddrType1(4151,'streeta','pune','mha',1007),979786,453567)));
insert into Publisher values('tanaya',AddrType1(6002,'streeta','nasik','mha',1007),
    BranchTableType(BranchType( AddrType1(4151,'streeta','pune','kolhapur',1007),979786,453567)));
insert into Publisher values('arpita',AddrType1(6002,'streeta','nasik','mha',1007),
    BranchTableType(BranchType( AddrType1(4151,'streeta','nasik','kolhapur',1007),979786,453567)));
    
    
    
insert into book
	SELECT 'maths','12-may-2000',ref(pub),AuthorListType(ref(aut)) 
	FROM Publisher pub,Author aut
	WHERE pub.name='arpita' and aut.name='Shivani';
insert into book
	SELECT 'idare','12-may-2000',ref(pub),AuthorListType(ref(aut)) 
	FROM Publisher pub,Author aut 
	WHERE pub.name='prasad' and aut.name='Ganesh';
insert into book
	SELECT 'a','12-may-2000',ref(pub),AuthorListType(ref(aut))
	FROM Publisher pub,Author aut 
	WHERE pub.name='prasad' and aut.name='Shivani';
insert into book
    SELECT 'maths','12-may-2000',ref(pub),AuthorListType(ref(aut))
    FROM Publisher pub,Author aut 
    WHERE pub.name='arpita' and aut.name='Revati';
insert into book
	SELECT 'idare','12-may-2003',ref(pub),AuthorListType(ref(aut))
	FROM Publisher pub,Author aut 
	WHERE pub.name='aditi' and aut.name='Shivani';
    
insert into book
	SELECT 'maths','2000',ref(pub),AuthorListType(ref(aut)) 
	FROM Publisher pub,Author aut
	WHERE pub.name='arpita' and aut.name='Shivani';
insert into book
	SELECT 'idare','12-may-2003',ref(pub),AuthorListType(ref(aut)) 
	FROM Publisher pub,Author aut 
	WHERE pub.name='arpita' and aut.name='Ganesh';
insert into book
	SELECT 'a','25-may-2000',ref(pub),AuthorListType(ref(aut))
	FROM Publisher pub,Author aut 
	WHERE pub.name='prasad' and aut.name='Revati';
insert into book
    SELECT 'b','12-may-2001',ref(pub),AuthorListType(ref(aut))
    FROM Publisher pub,Author aut 
    WHERE pub.name='arpita' and aut.name='Revati';
insert into book
	SELECT 'c','12-may-2001',ref(pub),AuthorListType(ref(aut))
	FROM Publisher pub,Author aut 
	WHERE pub.name='aditi' and aut.name='Shivani';
    


SELECT a.name
	FROM author a, book b, table(b.authors) v
	WHERE v.column_value = ref(a)
	GROUP BY a.name having count(*) > 1;	

SELECT a.name
	FROM author a, publisher p
	WHERE a.addr.pincode = p.addr.pincode;
    
SELECT p.name
	FROM publisher p, table(p.branches)
	GROUP BY p.name having count(*)> = all (SELECT count(*)
		FROM publisher p, table(p.branches)
		GROUP BY name);

SELECT title
	FROM author a, book b, table(b.authors) v
	WHERE v.column_value = ref(a)
	GROUP BY title having count(*) > 1;
