
-- Solved using chat gpt
--headquarter
-- Step 1

--
--CREATE TABLE Customer (
--    Customer_id INT PRIMARY KEY,
--    Customer_name VARCHAR(50),
--    City_id INT,
--    First_order_date DATE
--);
--
--CREATE TABLE Walk_in_customers (
--    Customer_id INT REFERENCES Customer(Customer_id),
--    tourism_guide VARCHAR(50),
--    Time TIMESTAMP
--);
--
--CREATE TABLE Mail_order_customers (
--    Customer_id INT REFERENCES Customer(Customer_id),
--    post_address VARCHAR(100),
--    Time TIMESTAMP
--);

--------------------------------------------------------------------------------

--Sales database
--Step 2
--
--CREATE TABLE Headquarter (
--    City_id INT PRIMARY KEY,
--    City_name VARCHAR(50),
--    Headquarter_addr VARCHAR(100),
--    State VARCHAR(50),
--    Time TIMESTAMP
--);
--
--CREATE TABLE Stores (
--    Store_id INT PRIMARY KEY,
--    City_id INT REFERENCES Headquarter(City_id),
--    Phone VARCHAR(20),
--    Time TIMESTAMP
--);
--
--CREATE TABLE Items (
--    Item_id INT PRIMARY KEY,
--    Descriptions VARCHAR(100),
--    Item_size VARCHAR(10),
--    Weight INT,
--    Unit_price DECIMAL(10, 2),
--    Time_of_entry TIMESTAMP
--);

--
--CREATE TABLE Stored_items (
--    Store_id INT REFERENCES Stores(Store_id),
--    Item_id INT REFERENCES Items(Item_id),
--    Quantity_held INT,
--    Time TIMESTAMP
--);
--
--CREATE TABLE Orders (
--    Order_no INT PRIMARY KEY,
--    Order_date DATE,
--    Customer_id INT REFERENCES Customer(Customer_id)
--);
--
--
--CREATE TABLE Ordered_item (
--    Order_no INT REFERENCES Orders(Order_no),
--    Item_id INT REFERENCES Items(Item_id),
--    Quantity_ordered INT,
--    Ordered_price DECIMAL(10, 2),
--    Time TIMESTAMP
--);

--------------------------------------------------------------------------------
-- STEP 3; creating dimension table


---- Dimension table for city


--CREATE TABLE dim_city (
--    city_id INT PRIMARY KEY,
--    city_name VARCHAR(50),
--    headquarter_addr VARCHAR(50),
--    state VARCHAR(50)
--);

-- Dimension table for customer

--CREATE TABLE dim_customer (
--    customer_id INT PRIMARY KEY,
--    customer_name VARCHAR(50),
--    city_id INT,
--    first_order_date DATE,
--    FOREIGN KEY (city_id) REFERENCES dim_city(city_id)
--);
--

--
---- Dimension table for store
--CREATE TABLE dim_store (
--    store_id INT PRIMARY KEY,
--    city_id INT,
--    phone VARCHAR(20),
--    FOREIGN KEY (city_id) REFERENCES dim_city(city_id)
--);
--
---- Dimension table for item
--CREATE TABLE dim_item (
--    item_id INT PRIMARY KEY,
--    descriptions VARCHAR(50),
--    Item_size INT,
--    weight DECIMAL(5,2),
--    unit_price DECIMAL(8,2)
--);
--
---- Dimension table for order
--CREATE TABLE dim_order (
--    order_no INT PRIMARY KEY,
--    order_date DATE,
--    customer_id INT,
--    FOREIGN KEY (customer_id) REFERENCES dim_customer(customer_id)
--);
--------------------------------------------------------------------------------
-- Step 4 :creating fact tables




--CREATE TABLE Fact_Order (
--    Order_no INT PRIMARY KEY,
--    Order_date DATE NOT NULL,
--    Customer_id INT NOT NULL,
--    Store_id INT NOT NULL,
--    Item_id INT NOT NULL,
--    Quantity_ordered INT NOT NULL,
--    Ordered_price DECIMAL(10,2) NOT NULL,
--    FOREIGN KEY (Customer_id) REFERENCES Dim_Customer(Customer_id),
--    FOREIGN KEY (Store_id) REFERENCES Dim_Store(Store_id),
--    FOREIGN KEY (Item_id) REFERENCES Dim_Item(Item_id)
--);
--
--CREATE TABLE Fact_Item_Inventory (
--    Store_id INT NOT NULL,
--    Item_id INT NOT NULL,
--    Quantity_held INT NOT NULL,
--    PRIMARY KEY (Store_id, Item_id),
--    FOREIGN KEY (Store_id) REFERENCES Dim_Store(Store_id),
--    FOREIGN KEY (Item_id) REFERENCES Dim_Item(Item_id)
--);

--------------------------------------------------------------------------------
--step 5 : inserting values in headquarter

-- Insert data into the Customer table
--INSERT INTO Customer (Customer_id, Customer_name, City_id, First_order_date)
--VALUES (1, 'John Doe', 1, '01-JAN-2022');
--INSERT INTO Customer (Customer_id, Customer_name, City_id, First_order_date)
--VALUES (2, 'Jane Smith', 2, '15-FEB-2022');
--INSERT INTO Customer (Customer_id, Customer_name, City_id, First_order_date)
--VALUES (3, 'Bob Johnson', 3, '10-MAR-2022');
--
---- Insert data into the Walk-in_customers table
--INSERT INTO Walk_in_customers (Customer_id, tourism_guide, Time)
--VALUES (1, 'Joe', '01-JAN-2022 10:00:00');
--INSERT INTO Walk_in_customers (Customer_id, tourism_guide, Time)
--VALUES (2, 'Susan', '15-FEB-2022 11:00:00');
--INSERT INTO Walk_in_customers (Customer_id, tourism_guide, Time)
--VALUES (3, 'Mike', '10-MAR-2022 12:00:00');
--
---- Insert data into the Mail_order_customers table
--INSERT INTO Mail_order_customers (Customer_id, post_address, Time)
--VALUES (1, '123 Main St., Anytown, USA', '01-JAN-2022 10:00:00');
--INSERT INTO Mail_order_customers (Customer_id, post_address, Time)
--VALUES (2, '456 Oak St., Anothercity, USA', '15-FEB-2022 11:00:00');
--INSERT INTO Mail_order_customers (Customer_id, post_address, Time)
--VALUES (3, '789 Maple St., Somewhere, USA', '10-MAR-2022 12:00:00');

--------------------------------------------------------------------------------
--step 6 : Inserting values in sales table

----
----Headquarters table:
--
--INSERT INTO Headquarter (City_id, City_name, Headquarter_addr, State, Time) VALUES
--(1, 'Mumbai', '123 Main St, Dadar, Mumbai', 'Maharashtra', TO_TIMESTAMP('2022-06-01 10:00:00', 'YYYY-MM-DD HH24:MI:SS'));
--INSERT INTO Headquarter (City_id, City_name, Headquarter_addr, State, Time) VALUES
--(2, 'Delhi', '456 Central Rd, Connaught Place, Delhi', 'Delhi', TO_TIMESTAMP('2022-06-01 10:00:00', 'YYYY-MM-DD HH24:MI:SS'));
--INSERT INTO Headquarter (City_id, City_name, Headquarter_addr, State, Time) VALUES
--(3, 'Bangalore', '789 Park Ave, Indiranagar, Bangalore', 'Karnataka', TO_TIMESTAMP('2022-06-01 10:00:00', 'YYYY-MM-DD HH24:MI:SS'));
--
----Stores table:
--
--INSERT INTO Stores (Store_id, City_id, Phone, Time) VALUES 
--(101, 1, '+91-9876543210', TO_TIMESTAMP('2022-03-14 10:00:00', 'YYYY-MM-DD HH24:MI:SS'));
--INSERT INTO Stores (Store_id, City_id, Phone, Time) VALUES 
--(102, 2, '+91-9876543211', TO_TIMESTAMP('2022-03-14 10:00:00', 'YYYY-MM-DD HH24:MI:SS'));
--INSERT INTO Stores (Store_id, City_id, Phone, Time) VALUES 
--(103, 3, '+91-9876543212', TO_TIMESTAMP('2022-03-14 10:00:00', 'YYYY-MM-DD HH24:MI:SS'));
--
----Items table:
--
--INSERT INTO Items (Item_id, Descriptions, Item_size, Weight, Unit_price,  Time_of_entry) VALUES
--(1, 'Shirt', 'L', 0.5, 999, TO_TIMESTAMP('2022-03-13 10:00:00', 'YYYY-MM-DD HH24:MI:SS'));
--INSERT INTO Items (Item_id, Descriptions, item_size, Weight, Unit_price,  Time_of_entry) VALUES
--(2, 'Jeans', 'M', 0.7, 1999, TO_TIMESTAMP('2022-03-13 10:00:00', 'YYYY-MM-DD HH24:MI:SS'));
--INSERT INTO Items (Item_id, Descriptions, item_size, Weight, Unit_price,  Time_of_entry) VALUES
--(3, 'T-Shirt', 'S', 0.2 , 499, TO_TIMESTAMP('2022-03-13 10:00:00', 'YYYY-MM-DD HH24:MI:SS'));
--
----Stored_items table:
--
--INSERT INTO Stored_items (Store_id, Item_id, Quantity_held, Time) VALUES
--(101, 1, 50, TO_TIMESTAMP('2022-03-13 10:00:00', 'YYYY-MM-DD HH24:MI:SS'));
--INSERT INTO Stored_items (Store_id, Item_id, Quantity_held, Time) VALUES
--(102, 2, 20, TO_TIMESTAMP('2022-03-13 10:00:00', 'YYYY-MM-DD HH24:MI:SS'));
--INSERT INTO Stored_items (Store_id, Item_id, Quantity_held, Time) VALUES
--(103, 2, 30, TO_TIMESTAMP('2022-03-13 10:00:00', 'YYYY-MM-DD HH24:MI:SS'));
--
--
----Order table:
--
--INSERT INTO Orders (Order_no, Order_date, Customer_id) VALUES
--(1001, TO_TIMESTAMP('2022-03-12 10:00:00', 'YYYY-MM-DD HH24:MI:SS'), 1);
--INSERT INTO Orders (Order_no, Order_date, Customer_id) VALUES
--(1002, TO_TIMESTAMP('2022-03-12 10:00:00', 'YYYY-MM-DD HH24:MI:SS'), 2);
--INSERT INTO Orders (Order_no, Order_date, Customer_id) VALUES
--(1003, TO_TIMESTAMP('2022-03-13 10:00:00', 'YYYY-MM-DD HH24:MI:SS'), 1);
--INSERT INTO Orders (Order_no, Order_date, Customer_id) VALUES
--(1004, TO_TIMESTAMP('2022-03-14 10:00:00', 'YYYY-MM-DD HH24:MI:SS'), 3);
--
----Ordered_item table
--
--INSERT INTO Ordered_item (Order_no, Item_id, Quantity_ordered, Ordered_price, Time)
--VALUES (1001, 1, 2, 10.99, TO_TIMESTAMP('2022-01-01 10:00:00', 'YYYY-MM-DD HH24:MI:SS'));
--
--INSERT INTO Ordered_item (Order_no, Item_id, Quantity_ordered, Ordered_price, Time)
--VALUES (1001, 3, 1, 19.99, TO_TIMESTAMP('2022-01-01 10:00:00',  'YYYY-MM-DD HH24:MI:SS'));
--
--INSERT INTO Ordered_item (Order_no, Item_id, Quantity_ordered, Ordered_price, Time)
--VALUES (1002, 2, 5, 5.99, TO_TIMESTAMP('2022-01-03 14:30:00',  'YYYY-MM-DD HH24:MI:SS'));
--
--INSERT INTO Ordered_item (Order_no, Item_id, Quantity_ordered, Ordered_price, Time)
--VALUES (1004, 3, 2, 19.99, '2022-01-05 09:15:00');
--
--select * from Ordered_item;

--------------------------------------------------------------------------------
--step 07 : inserting values in dimension table
----
---- Insert data into dim_city table
--INSERT INTO dim_city (city_id, city_name, headquarter_addr, state)
--VALUES (1, 'Mumbai', '123 Main St', 'Maharashtra');
--INSERT INTO dim_city (city_id, city_name, headquarter_addr, state)
--VALUES (2, 'Delhi', '456 Elm St', 'Delhi');
--INSERT INTO dim_city (city_id, city_name, headquarter_addr, state)
--VALUES (3, 'Bangalore', '789 Oak St', 'Karnataka');
--
---- Insert data into dim_customer table
--INSERT INTO dim_customer (customer_id, customer_name, city_id, first_order_date)
--VALUES (101, 'Rahul Singh', 1, TO_DATE('2022-01-01 10:00:00', 'YYYY-MM-DD HH24:MI:SS'));
--INSERT INTO dim_customer (customer_id, customer_name, city_id, first_order_date)
--VALUES (102, 'Priya Patel', 2, TO_DATE('2022-02-15 11:30:00', 'YYYY-MM-DD HH24:MI:SS'));
--INSERT INTO dim_customer (customer_id, customer_name, city_id, first_order_date)
--VALUES (103, 'Ravi Gupta', 3, TO_DATE('2022-03-10 12:45:00', 'YYYY-MM-DD HH24:MI:SS'));
--INSERT INTO dim_customer (customer_id, customer_name, city_id, first_order_date)
--VALUES (104, 'Amit Sharma', 1, TO_DATE('2022-04-20 14:00:00', 'YYYY-MM-DD HH24:MI:SS'));
--INSERT INTO dim_customer (customer_id, customer_name, city_id, first_order_date)
--VALUES (105, 'Sneha Joshi', 2, TO_DATE('2022-05-05 15:15:00', 'YYYY-MM-DD HH24:MI:SS'));
--
--
---- Sample data for dim_store
--INSERT INTO dim_store (store_id, city_id, phone) VALUES
--(1, 1, '9876543210');
--INSERT INTO dim_store (store_id, city_id, phone) VALUES
--(2, 1, '9988776655');
--INSERT INTO dim_store (store_id, city_id, phone) VALUES
--(3, 2, '9876543211');
--
---- Sample data for dim_item
--INSERT INTO dim_item (item_id, descriptions, item_size, weight, unit_price) VALUES
--(1, 'Shirt', 42, 0.25, 499.99);
--INSERT INTO dim_item (item_id, descriptions, item_size, weight, unit_price) VALUES
--(2, 'Pants', 36, 0.35, 799.99);
--INSERT INTO dim_item (item_id, descriptions, item_size, weight, unit_price) VALUES
--(3, 'Shoes', 10, 0.75, 1499.99);
--
---- Sample data for dim_order
--INSERT INTO dim_order (order_no, order_date, customer_id) VALUES
--(1, TO_DATE('2022-03-12', 'yyyy-mm-dd'), 101);
--INSERT INTO dim_order (order_no, order_date, customer_id) VALUES
--(2, TO_DATE('2022-02-15', 'yyyy-mm-dd'), 102);
--INSERT INTO dim_order (order_no, order_date, customer_id) VALUES
--(3, TO_DATE('2022-01-01', 'yyyy-mm-dd'), 103);

--------------------------------------------------------------------------------
--step08 : Inserting valus in fact tables

--Insert data into fact tables
--
--INSERT INTO Fact_Order (Order_no, Order_date, Customer_id, Store_id, Item_id, Quantity_ordered, Ordered_price)
--VALUES (1001, TO_DATE('2022-01-05', 'YYYY-MM-DD'), 101, 1, 1, 5, 20.00);
--
--INSERT INTO Fact_Order (Order_no, Order_date, Customer_id, Store_id, Item_id, Quantity_ordered, Ordered_price)
--VALUES (1002, TO_DATE('2022-01-07', 'YYYY-MM-DD'), 102, 2, 2, 3, 25.50);
--
--INSERT INTO Fact_Item_Inventory (Store_id, Item_id, Quantity_held)
--VALUES (1, 1, 100);
--
--INSERT INTO Fact_Item_Inventory (Store_id, Item_id, Quantity_held)
--VALUES (2, 2, 50);

--------------------------------------------------------------------------------
--step 09 : query solving 

--Q1

--SELECT 
--    s.Store_id, 
--    c.City_name, 
--    c.State, 
--    s.Phone, 
--    i.descriptions, 
--    i.Item_size, 
--    i.Weight, 
--    i.Unit_price
--FROM 
--    Fact_Order o 
--    JOIN Dim_Store s ON o.Store_id = s.Store_id
--    JOIN Dim_City c ON s.City_id = c.City_id 
--    JOIN Dim_Item i ON o.Item_id = i.Item_id 
--WHERE 
--    i.descriptions = 'Shirt';


--Query 2: Find all the orders along with customer name and order date that can be fulfilled by a given store.
--
--SELECT 
--    o.Order_no, 
--    c.Customer_name, 
--    o.Order_date
--FROM 
--    Fact_Order o 
--    JOIN Dim_Customer c ON o.Customer_id = c.Customer_id
--WHERE 
--    o.Store_id = 2


--Q3
--SELECT 
--    s.Store_id, 
--    c.City_name, 
--    s.Phone
--FROM 
--    Fact_Order o 
--    JOIN Dim_Store s ON o.Store_id = s.Store_id 
--    JOIN Dim_City c ON s.City_id = c.City_id 
--WHERE 
--    o.Customer_id = 102
    
    
--Query 4 Find the headquarter address along with city and state of all stores that hold stocks of an item above a particular level.
--
--SELECT DISTINCT 
--    h.headquarter_addr, 
--    h.city_name, 
--    h.state
--FROM 
--    Fact_Item_Inventory f
--    JOIN Dim_Store s ON f.store_id = s.store_id
--    JOIN Dim_City c ON s.city_id = c.city_id
--    JOIN Dim_Item i ON f.item_id = i.item_id
--    JOIN Headquarter h ON c.city_id = h.city_id
--WHERE 
--    f.quantity_held > 30;


--Query 5 For each customer order, show the items ordered along with description, store id and city name and the stores that hold the items.

--SELECT 
--    o.order_no, 
--    i.descriptions, 
--    s.store_id,
--    c.city_name, 
--    s.phone
--FROM 
--    Fact_Order o
--    JOIN Dim_Customer d ON o.customer_id = d.customer_id
--    JOIN Dim_Item i ON o.item_id = i.item_id
--    JOIN Dim_Store s ON o.store_id = s.store_id
--    JOIN Dim_City c ON s.city_id = c.city_id
--WHERE 
--    o.order_no = 1001

--Query 6 Find the city and the state in which a given customer lives.

--SELECT 
--    c.city_name, 
--    c.state
--FROM 
--    Dim_Customer d
--    JOIN Dim_City c ON d.city_id = c.city_id
--WHERE 
--    d.customer_name = 'Ravi Gupta';

----Query 7 Find the stock level of a particular item in all stores in a particular city.
--
--SELECT 
--    dim_store.store_id, 
--    dim_store.city_id, 
--    dim_city.city_name, 
--    dim_item.descriptions, 
--    dim_item.item_size, 
--    dim_item.weight, 
--    dim_item.unit_price, 
--    fact_item_inventory.quantity_held
--FROM 
--    dim_store
--    JOIN dim_city ON dim_city.city_id = dim_store.city_id
--    JOIN fact_item_inventory ON fact_item_inventory.store_id = dim_store.store_id
--    JOIN dim_item ON dim_item.item_id = fact_item_inventory.item_id
--WHERE 
--    dim_city.city_name = 'Mumbai'
--    AND dim_item.descriptions = 'Shirt'
--    AND fact_item_inventory.quantity_held > 30;

--Query 9 To find the walk-in customers, mail order customers, and dual customers, we can use the following SQL query:
--
--SELECT 
--    Customer_id, 
--       CASE WHEN 
--                COUNT(DISTINCT Order_date) = 1 THEN 'Mail Order'
--            WHEN 
--                COUNT(DISTINCT Order_date) > 1 THEN 'Dual'
--            ELSE 
--                'Walk-in' 
--            END AS 
--                Customer_Type
--FROM 
--    fact_order
--GROUP BY 
--    Customer_id;


--Query 8 Find the items, quantity ordered, customer, store and city of an order

SELECT 
    f.Order_no, 
    i.descriptions, 
    f.Quantity_ordered, 
    c.Customer_name, 
    s.Store_id, 
    c.First_order_date, 
    c.City_id, 
    ci.City_name
FROM 
    fact_order f
    JOIN Dim_Item i ON f.Item_id = i.Item_id
    JOIN Dim_Customer c ON f.Customer_id = c.Customer_id
    JOIN Dim_Store s ON f.Store_id = s.Store_id
    JOIN Dim_City ci ON s.City_id = ci.City_id
WHERE 
    f.Order_no = 1001;



